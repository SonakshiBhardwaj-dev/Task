﻿
    public class Team

{

    public int Id { get; internal set; }



    public string teamName { get; set; }

   
}

  