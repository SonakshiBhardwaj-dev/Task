﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tasktracker.Models
{
    public class TeamMember
    {


        public int Id { get; internal set; }
        public string TeamName { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeAlias { get; set; }
        public string LastTaskTime { get; set; }


        public string CurrentTask { get; set; }
        public int Shift { get; internal set; }
    }
}
