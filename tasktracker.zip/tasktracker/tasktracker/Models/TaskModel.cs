﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tasktracker.Models
{
    public class TaskModel
    {


        public int Id { get; internal set; }
        public string Task { get; set; }
        public string Shift { get; set; }
        public int UserId { get; internal set; }
        public string LastTaskTime { get; set; }


        public string CreateTime { get; set; }
        
    }
}

