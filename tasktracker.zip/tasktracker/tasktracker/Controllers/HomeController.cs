﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Data.SqlClient;
using tasktracker.Models;

public class HomeController : Controller
{


    SqlConnectionStringBuilder connectionString = new SqlConnectionStringBuilder("Server=cldkiravi05.usdev.deloitte.com,1433;Initial Catalog=Task Tracker;Persist Security Info=False;User ID=sa;Password=Portal1!;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;");
    private object JsonRequestBehavior;

    public ActionResult Index()
    {
        return View();
    }

    public ActionResult Team()
    {
        return View();
    }

    [HttpGet]
    public JsonResult GetTeamList()
    {


        //Be sure to replace <YourTable> with the actual name of the Table
        string queryString = "select * from Team ORDER BY Id DESC";
        List<Team> TeamList = new List<Team>();
        using (SqlConnection connection = new SqlConnection(connectionString.ConnectionString))
        using (SqlCommand command = connection.CreateCommand())
        {
            command.CommandText = queryString;

            connection.Open();

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    try
                    {
                        Team team = new Team
                        {
                            Id = Convert.ToInt32(reader["Id"]),

                            teamName = reader["teamName"] != null ? reader["teamName"].ToString() : string.Empty
                        };

                        TeamList.Add(team);
                    }
                    catch (Exception e)
                    {
                    }

                }
            }
        }
        return Json(TeamList);

    }


    [HttpGet]
    public JsonResult GetTeamMembers(string TeamName)
    {
        //Be sure to replace <YourTable> with the actual name of the Table
        string queryString = "select * from UserInfo WHERE " + "TeamName = '" + TeamName +"' ;";
        List<TeamMember> TeamMemberList = new List<TeamMember>();
        using (SqlConnection connection = new SqlConnection(connectionString.ConnectionString))
        using (SqlCommand command = connection.CreateCommand())
        {
            command.CommandText = queryString;

            connection.Open();

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    try
                    {
                        TeamMember teamMember = new TeamMember
                        {
                            Id = Convert.ToInt32(reader["Id"]),

                            TeamName = reader["TeamName"] != null ? reader["TeamName"].ToString() : string.Empty,
                            EmployeeName = reader["EmployeeName"] != null ? reader["EmployeeName"].ToString() : string.Empty,
                            EmployeeAlias = reader["EmployeeAlias"] != null ? reader["EmployeeAlias"].ToString() : string.Empty,
                            CurrentTask = reader["CurrentTAsk"] != null ? reader["CurrentTask"].ToString() : string.Empty,
                            LastTaskTime = reader["LastTaskTime"].ToString(),
                            Shift = Convert.ToInt32(reader["Shift"]),
                        };

                        TeamMemberList.Add(teamMember);
                    }
                    catch (Exception e)
                    {
                    }

                }
            }
        }
        return Json(TeamMemberList);

    }

    private JsonResult Json(List<TeamMember> TeamNameList, object allowGet)
    {
        throw new NotImplementedException();
    }

    public JsonResult UpdateTasks(int id, int? Shift = null, int? Task = null)
    {



        string queryString = "update Tasks " +
            "SET Shift=" + Shift + ", " +
"Task=" + Task + " " +
"WHERE Id= " + id;
        List<TaskModel> TasksList = new List<TaskModel>();
        using (SqlConnection connection = new SqlConnection(connectionString.ConnectionString))
        using (SqlCommand command = connection.CreateCommand())
        {
            command.CommandText = queryString;

            connection.Open();

            using (SqlDataReader reader = command.ExecuteReader())
            {
            }
        }
        return Json(false, JsonRequestBehavior);
    }

    private JsonResult Json(bool v, object denyGet)
    {
        throw new NotImplementedException();
    }
}
